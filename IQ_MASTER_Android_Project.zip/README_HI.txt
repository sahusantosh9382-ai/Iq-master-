IQ MASTER Android project

Is folder ko Android Studio mein Open karein.

APK banane ke steps:
1. Android Studio install/open karein.
2. File > Open se is extracted folder ko select karein.
3. Gradle sync complete hone dein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) par click karein.
5. APK app/build/outputs/apk/debug/app-debug.apk mein milega.

Note:
- Is environment mein Android SDK/Gradle build system available nahi tha, isliye yahan installable APK compile nahi hua.
- Yeh Android WebView wrapper project hai; uploaded HTML game assets/index.html mein rakha gaya hai.
- Google Play/Aptoide publish karne se pehle device par testing, privacy/data-safety details, app icon, screenshots aur store requirements complete karein.
- Current HTML mein language selector ke sabhi question translations available hone ka claim nahi hai; app mein bhi HTML ki current functionality hi rahegi.
